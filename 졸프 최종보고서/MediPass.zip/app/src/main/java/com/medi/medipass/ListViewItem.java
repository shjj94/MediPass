package com.medi.medipass;

/**
 * Created by Sohyeon on 2016-04-14.
 */
public class ListViewItem {
    private String item_date;
    private String item_disName;

    public void setItem_date(String item_date) {
        this.item_date = item_date;
    }

    public void setItem_disName(String item_disName) {
        this.item_disName = item_disName;
    }

    public String getItem_date() {
        return item_date;
    }

    public String getItem_disName() {
        return item_disName;
    }
}
