package com.medi.medipass;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MyPageLogInfo extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_page_loginfo);
    }
}
