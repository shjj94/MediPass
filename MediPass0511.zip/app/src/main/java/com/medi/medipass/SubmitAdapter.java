package com.medi.medipass;

public class SubmitAdapter {
}