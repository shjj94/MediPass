package com.medi.medipass;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by Elizabeth on 2016-04-07.
 */
public class HospitalNfc extends AppCompatActivity{

    //아직 쓸모 없음. 나중에 메인에서 접수버튼 분리시 사용할 예정
//    public static Activity hospital_activity;
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.home);
//
//        hospital_activity=HospitalNfc.this;
//        Dialog dialog = new Dialog(this);
//        dialog.setContentView(R.layout.treat_recept);
//        dialog.setTitle("Custom Dialog");
//
//        TextView tv = (TextView) dialog.findViewById(R.id.text);
//        tv.setText("Hello. This is a Custom Dialog !");
//
//        ImageView iv = (ImageView) dialog.findViewById(R.id.image);
//        iv.setImageResource(R.drawable.logo);
//
//        dialog.show();
//    }
}
